package com.clearpath.guard

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence? =
        "ClearPath লক চালু থাকলে অ্যাডমিন বন্ধ করা যাবে না।"
}

package com.clearpath.guard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.VpnService

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (Prefs.vpnWanted(c) && VpnService.prepare(c) == null) {
            c.startService(Intent(c, DnsVpnService::class.java))
        }
    }
}

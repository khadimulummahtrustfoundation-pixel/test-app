package com.clearpath.guard

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var bVpn: Button
    private lateinit var bA11y: Button
    private lateinit var bAdmin: Button
    private lateinit var bLock: Button
    private lateinit var bRemove: Button
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { refresh(); h.postDelayed(this, 20000) }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun button(t: String, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setOnClickListener { f() }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        root.addView(TextView(this).apply { text = "ClearPath"; textSize = 30f })
        root.addView(TextView(this).apply { text = "অ্যাডাল্ট কনটেন্ট ব্লক ও আনইনস্টল লক" })
        info = TextView(this).apply { textSize = 16f; setPadding(0, dp(18), 0, dp(18)) }
        root.addView(info)
        bVpn = button("১. DNS ফিল্টার চালু করুন") { startVpnFlow() }
        bA11y = button("২. সার্চ ব্লকার চালু করুন") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        bAdmin = button("৩. ডিভাইস অ্যাডমিন চালু করুন") {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(this@MainActivity, AdminReceiver::class.java))
                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "লক চলাকালীন আনইনস্টল ঠেকাতে এটি দরকার।")
            })
        }
        bLock = button("৪. লক শুরু করুন") { confirmLock() }
        bRemove = button("অ্যাডমিন বন্ধ করুন (আনইনস্টলের আগে)") {
            if (!Prefs.isLocked(this)) {
                dpm().removeActiveAdmin(ComponentName(this, AdminReceiver::class.java))
                refresh()
            }
        }
        listOf(bVpn, bA11y, bAdmin, bLock, bRemove).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    private fun dpm() = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
    private fun adminOk() = dpm().isAdminActive(ComponentName(this, AdminReceiver::class.java))
    private fun a11yOk(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains("$packageName/") && s.contains("GuardService")
    }

    @Suppress("DEPRECATION")
    private fun startVpnFlow() {
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, 1) else startVpn()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK) startVpn()
    }

    private fun startVpn() {
        Prefs.setVpnWanted(this, true)
        startService(Intent(this, DnsVpnService::class.java))
        h.postDelayed({ refresh() }, 800)
    }

    private fun confirmLock() {
        val hrs = Prefs.LOCK_MS / 3600000
        val dur = if (hrs >= 24) "${hrs / 24} দিন" else "$hrs ঘণ্টা"
        AlertDialog.Builder(this)
            .setTitle("লক শুরু করবেন?")
            .setMessage("শুরু করলে $dur ধরে অ্যাপটি আনইনস্টল বা বন্ধ করা যাবে না। এটা ফেরানো যাবে না।")
            .setPositiveButton("হ্যাঁ, লক করুন") { _, _ -> Prefs.startLock(this); refresh() }
            .setNegativeButton("না", null)
            .show()
    }

    private fun refresh() {
        val v = DnsVpnService.running
        val a = a11yOk()
        val d = adminOk()
        val locked = Prefs.isLocked(this)
        val sb = StringBuilder()
        sb.append(if (v) "✅" else "❌").append(" DNS ফিল্টার (সব অ্যাপে অ্যাডাল্ট সাইট ব্লক)\n")
        sb.append(if (a) "✅" else "❌").append(" সার্চ ব্লকার (যেকোনো জায়গায় সার্চ)\n")
        sb.append(if (d) "✅" else "❌").append(" ডিভাইস অ্যাডমিন (আনইনস্টল সুরক্ষা)\n")
        if (locked) {
            val ms = Prefs.remainingMs(this)
            sb.append("\n🔒 লক চালু। বাকি: ${ms / 86400000} দিন ${ms % 86400000 / 3600000} ঘণ্টা ${ms % 3600000 / 60000} মিনিট")
        } else if (Prefs.started(this)) {
            sb.append("\n🔓 লকের মেয়াদ শেষ। এখন আনইনস্টল করা যাবে।")
        }
        info.text = sb
        bVpn.isEnabled = !v
        bA11y.isEnabled = !a
        bAdmin.isEnabled = !d
        bLock.isEnabled = v && a && d && !locked
        bRemove.visibility = if (!locked && d) View.VISIBLE else View.GONE
    }
}

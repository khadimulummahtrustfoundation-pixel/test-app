package com.clearpath.guard

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class GuardService : AccessibilityService() {
    private var lastBlock = 0L
    private var lastScan = 0L

    companion object {
        private const val APP_LABEL = "clearpath"
        // লক চলাকালীন এই অ্যাপগুলোতে ClearPath-এর নাম দেখা গেলে ব্লক হবে
        private val GUARDED = setOf(
            "com.android.settings", "com.google.android.packageinstaller",
            "com.android.packageinstaller", "com.samsung.android.packageinstaller",
            "com.miui.packageinstaller", "com.google.android.permissioncontroller",
            "com.android.vending", "com.miui.securitycenter", "com.coloros.safecenter"
        )
        private val URL_BARS = mapOf(
            "com.android.chrome" to "com.android.chrome:id/url_bar",
            "com.brave.browser" to "com.brave.browser:id/url_bar",
            "com.microsoft.emmx" to "com.microsoft.emmx:id/url_bar",
            "com.sec.android.app.sbrowser" to "com.sec.android.app.sbrowser:id/location_bar_edit_text",
            "org.mozilla.firefox" to "org.mozilla.firefox:id/mozac_browser_toolbar_url_view"
        )
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        try {
            if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                if (Words.bad(e.text.joinToString(" "))) { block(); return }
            }
            val now = SystemClock.elapsedRealtime()
            if (now - lastScan < 500) return
            lastScan = now
            val root = rootInActiveWindow ?: return

            URL_BARS[pkg]?.let { id ->
                val t = root.findAccessibilityNodeInfosByViewId(id)?.firstOrNull()?.text?.toString()
                if (t != null && Words.bad(t)) { block(); return }
            }

            if (pkg in GUARDED && Prefs.isLocked(this)) {
                val sb = StringBuilder()
                collect(root, sb, 0)
                val t = sb.toString().lowercase()
                val dnsOrTime = pkg == "com.android.settings" &&
                    (t.contains("private dns") || t.contains("automatic date") || t.contains("set time automatically"))
                if (t.contains(APP_LABEL) || dnsOrTime) block()
            }
        } catch (_: Exception) {
        }
    }

    private fun collect(n: AccessibilityNodeInfo?, sb: StringBuilder, d: Int) {
        if (n == null || d > 25 || sb.length > 6000) return
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        for (i in 0 until n.childCount) collect(n.getChild(i), sb, d + 1)
    }

    private fun block() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastBlock < 1500) return
        lastBlock = now
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(
            Intent(this, BlockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        )
    }

    override fun onInterrupt() {}
}

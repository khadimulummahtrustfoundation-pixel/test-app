package com.clearpath.guard

object Words {
    // নিজের মতো শব্দ যোগ বা বাদ দিতে পারেন
    private val en = listOf(
        "porn", "porno", "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn",
        "spankbang", "brazzers", "hentai", "xxx", "sex", "sex video", "sexy video", "nude",
        "nudes", "blue film", "bluefilm", "bangla choti", "choti golpo", "chodachudi", "nangta"
    )
    private val bn = listOf(
        "পর্ণ", "পর্নো", "চটি গল্প", "বাংলা চটি", "সেক্স", "যৌন ভিডিও",
        "নগ্ন", "ব্লু ফিল্ম", "ন্যাংটা", "নেংটা"
    )
    private val re = Regex(
        en.joinToString("|") { "\\b" + Regex.escape(it) + "\\b" },
        RegexOption.IGNORE_CASE
    )

    fun bad(t: String): Boolean = re.containsMatchIn(t) || bn.any { t.contains(it) }
}

package com.clearpath.guard

import android.net.VpnService
import android.content.Intent
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/** শুধু DNS প্রশ্ন নিজের হাতে নিয়ে ফ্যামিলি-সেফ DNS সার্ভারে পাঠায়। বাকি ট্রাফিক সরাসরি যায়। */
class DnsVpnService : VpnService() {
    companion object {
        @Volatile var running = false
        private const val FAKE_DNS = "10.77.0.1"
        private val UPSTREAMS = listOf("1.1.1.3", "1.0.0.3", "185.228.168.168")
    }

    private var tun: ParcelFileDescriptor? = null
    private val pool = Executors.newCachedThreadPool()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (tun == null) start()
        return START_STICKY
    }

    private fun start() {
        val fd = Builder()
            .setSession("ClearPath DNS")
            .addAddress("10.77.0.2", 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32)
            .establish() ?: return
        tun = fd
        running = true
        Thread { loop(fd) }.start()
    }

    private fun loop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (running) {
                val n = input.read(buf)
                if (n < 0) break
                if (n == 0) continue
                val pkt = buf.copyOf(n)
                pool.execute { handle(pkt, output) }
            }
        } catch (_: Exception) {
        }
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)

    private fun handle(pkt: ByteArray, out: FileOutputStream) {
        try {
            if ((pkt[0].toInt() shr 4) != 4 || pkt[9].toInt() != 17) return
            val ihl = (pkt[0].toInt() and 0x0F) * 4
            if (pkt.size < ihl + 8 || u16(pkt, ihl + 2) != 53) return
            val plen = u16(pkt, ihl + 4) - 8
            if (plen <= 0 || ihl + 8 + plen > pkt.size) return
            val q = pkt.copyOfRange(ihl + 8, ihl + 8 + plen)

            var resp: ByteArray? = null
            for (up in UPSTREAMS) {
                try {
                    DatagramSocket().use { s ->
                        protect(s)
                        s.soTimeout = 2500
                        s.send(DatagramPacket(q, q.size, InetAddress.getByName(up), 53))
                        val rb = ByteArray(4096)
                        val rp = DatagramPacket(rb, rb.size)
                        s.receive(rp)
                        resp = rb.copyOf(rp.length)
                    }
                    break
                } catch (_: Exception) {
                }
            }
            val r = resp ?: return

            val total = 28 + r.size
            val o = ByteArray(total)
            o[0] = 0x45; o[2] = (total shr 8).toByte(); o[3] = total.toByte()
            o[8] = 64; o[9] = 17
            System.arraycopy(pkt, 16, o, 12, 4)   // src = আগের dst
            System.arraycopy(pkt, 12, o, 16, 4)   // dst = আগের src
            var sum = 0
            for (i in 0 until 20 step 2) sum += u16(o, i)
            while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
            val ck = sum.inv() and 0xFFFF
            o[10] = (ck shr 8).toByte(); o[11] = ck.toByte()
            o[20] = 0; o[21] = 53
            o[22] = pkt[ihl]; o[23] = pkt[ihl + 1]
            val ul = 8 + r.size
            o[24] = (ul shr 8).toByte(); o[25] = ul.toByte()
            System.arraycopy(r, 0, o, 28, r.size)
            synchronized(out) { out.write(o) }
        } catch (_: Exception) {
        }
    }

    override fun onRevoke() { stopSelf() }

    override fun onDestroy() {
        running = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        super.onDestroy()
    }
}

package com.clearpath.guard

import android.content.Context
import android.os.SystemClock
import android.provider.Settings

object Prefs {
    // লকের মেয়াদ (মিলিসেকেন্ড)
    const val LOCK_MS = 3600000L

    private fun sp(c: Context) = c.getSharedPreferences("cp", Context.MODE_PRIVATE)
    private fun boots(c: Context) = Settings.Global.getInt(c.contentResolver, "boot_count", 0)

    fun startLock(c: Context) {
        sp(c).edit()
            .putLong("wall", System.currentTimeMillis())
            .putLong("el", SystemClock.elapsedRealtime())
            .putInt("boot", boots(c))
            .putBoolean("on", true).apply()
    }

    fun started(c: Context) = sp(c).getBoolean("on", false)

    fun remainingMs(c: Context): Long {
        val s = sp(c)
        if (!s.getBoolean("on", false)) return 0
        val wall = System.currentTimeMillis() - s.getLong("wall", 0)
        val sameBoot = boots(c) == s.getInt("boot", -1)
        val el = if (sameBoot) SystemClock.elapsedRealtime() - s.getLong("el", 0) else 0L
        return LOCK_MS - maxOf(wall, el)
    }

    fun isLocked(c: Context) = remainingMs(c) > 0

    fun setVpnWanted(c: Context, v: Boolean) = sp(c).edit().putBoolean("vpn", v).apply()
    fun vpnWanted(c: Context) = sp(c).getBoolean("vpn", false)
}

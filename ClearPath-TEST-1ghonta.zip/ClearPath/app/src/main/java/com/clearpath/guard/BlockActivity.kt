package com.clearpath.guard

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.parseColor("#12263A"))
        }
        root.addView(TextView(this).apply {
            text = "🚫 ব্লক করা হয়েছে\n\nএটা খোঁজা বা দেখা এখন বন্ধ।\nফোন রেখে একটু পানি খান, হাঁটুন বা অন্য কিছু করুন।"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        })
        root.addView(Button(this).apply {
            text = "ঠিক আছে"
            setOnClickListener { finish() }
        })
        setContentView(root)
    }
}
